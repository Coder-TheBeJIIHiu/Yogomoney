const groupToken 	= 'f34e4a3325ef4d8a831fd7aa1e33248c424c9c3899dccffdfdd2935e11e095ac77226ebb8e58e7825e995';
const groupID 	 	= 210612569;
const urlDB 	= 'mongodb+srv://coinwheel:oper4545@cluster0.hwz2s.mongodb.net/myFirstDatabase?retryWrites=true&w=majority';
const nameDB = 'myFirstDatabase' 
var mongoose = require('mongoose');
 
mongoose.connect('mongodb+srv://coinwheel:oper4545@cluster0.hwz2s.mongodb.net/myFirstDatabase?retryWrites=true&w=majority');
module.exports = {
  groupToken,
  groupID,

  urlDB,
  nameDB
};
